function calculo(altura, peso) {
 alturaD = altura * altura
  console.log (peso / alturaD)
    
}

calculo(1.75, 54)
